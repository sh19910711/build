#include <stdio.h>

int main() {
  puts("hello");
  return 0;
}
